import React, { useState } from 'react';
import axios from 'axios';

const MId = () => {

  const [markDetails, setDetails] = useState({stdResults:[],percentage:"",totalMarks:""});
  const [exmName,setExm]=useState("");
  const [studID,studId]=useState("");

  const GetByMId = (e) => {
    //e.preventDefault();
    axios
      .get("http://localhost:5247/api/Result/GetResultStudentby/" + studID)
      .then((response) => {
        console.log(response.data);
        setDetails(response.data);
      })
      .catch((error) => console.log(error));
  };
       
        return (
            <form>
                <br/><br/>
                <label><b>Enter Exam Name:</b></label>
                <input type='text' placeholder='Exam Name'style={{margin:10}} value={exmName}  onChange={(e) => setExm(e.target.value)}/>
                <label><b>Enter Student Id:</b></label>
                <input type='text' placeholder='Student ID' value={studID} onChange={(e) => studId(e.target.value)}/>
                <button type='button' className='btn btn-primary '  onClick={()=>GetByMId()}>Get Result</button>
                <br/><br/>
          <table className='table table-striped'>
            <thead>
              <tr>
                <th>Mark Id</th>
                <th>Exam Name</th>
                <th>Student Name</th>
                <th>Student Id</th>
                <th>Student Rollno</th>
                <th>Class Name</th>
                <th>SubJect Name</th>
                <th>Section</th>
                <th>Mark</th>
                <th>Result</th>
              </tr>
            </thead>
            <tbody>
              {}



                {
                    markDetails.stdResults.map((r)=>{
                        return(
        
                            <tr key={r.marksId}>
                            <td>{r.marksId}</td>
                            <td>{r.examName}</td>
                            <td>{r.studName}</td>
                            <td>{r.stuId}</td>
                            <td>{r.studRoll}</td>
                            <td>{r.className}</td>
                            <td>{r.subjectName}</td>
                            <td>{r.section}</td>
                            <td>{r.mark}</td>
                            <td style={{color:r.result=="Fail"?"red":"black"}}>{r.result}</td>
                          </tr>
                        )
                        
                    })
                }
              <tr>
                <td colSpan={8}></td>
                <td><label><b>Total:</b><label>{markDetails.totalMarks}</label></label></td>
                <td><label><b>Percentage:</b><label>{markDetails.percentage}</label></label></td>
              </tr>
            </tbody>
          </table>
          </form>
        );
    };
    

    export default MId;
