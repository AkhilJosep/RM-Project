import logo from './logo.svg';
import './App.css';
import MId from './studentdetails';

function App() {
  return (
    <div className="App">
   <MId />
    </div>
  );
}

export default App;
