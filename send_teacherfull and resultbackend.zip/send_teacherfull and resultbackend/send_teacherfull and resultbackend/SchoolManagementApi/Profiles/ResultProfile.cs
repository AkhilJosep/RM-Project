﻿using AutoMapper;
using SchoolManagementApi.DTOs;
using SchoolManagementApi.Entity;

namespace SchoolManagementApi.Profiles
{
    public class ResultProfile:Profile
    {
        public ResultProfile() 
        {
            CreateMap<ResultDto, StdResult>();
            CreateMap<StdResult, ResultDto>();
            CreateMap <ResultDisplayDto , StdResult>();
            CreateMap<StdResult, ResultDisplayDto>();
        }  
    }
}
