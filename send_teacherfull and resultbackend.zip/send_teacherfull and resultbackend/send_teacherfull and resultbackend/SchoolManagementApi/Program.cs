
using SchoolManagementApi.Entity;
using SchoolManagementApi.Repositories;

namespace SchoolManagementApi
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);

            // Add services to the container.
            builder.Services.AddAutoMapper(AppDomain.CurrentDomain.GetAssemblies());
            builder.Services.AddDbContext<MyContext>();
            builder.Services.AddTransient<TeacherRepository>();
           
            builder.Services.AddTransient<ResultRepository>();


            builder.Services.AddControllers();
            // Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
            builder.Services.AddEndpointsApiExplorer();
            builder.Services.AddSwaggerGen();
            //enable cors to the project
            builder.Services.AddCors(c =>
            {
                c.AddPolicy("AllowOrigin", options =>
                {
                    options.AllowAnyOrigin()    //allow any client url
                    .AllowAnyMethod() //allow any http method
                    .AllowAnyHeader(); //allow any header
                });
            });
            var app = builder.Build();

            // Configure the HTTP request pipeline.
            if (app.Environment.IsDevelopment())
            {
                app.UseSwagger();
                app.UseSwaggerUI();
            }

            app.UseAuthorization();
            app.UseCors("AllowOrigin");

            app.MapControllers();

            app.Run();
        }
    }
}
