﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SchoolManagementApi.Entity;
using SchoolManagementApi.Repository;

namespace SchoolManagementApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class StudentAttendanceController : ControllerBase
    {
        private readonly StudentAttendanceRepository studentAttendanceRepository;

        public StudentAttendanceController(StudentAttendanceRepository studentAttendanceRepository)
        {
            this.studentAttendanceRepository = studentAttendanceRepository;
        }

        [HttpPost("AddStudentAttendance")]
        public IActionResult AddStAttendace(StudentAttendance studentAttendance)
        {
            studentAttendanceRepository.AddAttendance(studentAttendance);
            return Ok(studentAttendance);
        }
        [HttpGet("GetAttendReportof/{id}")]
        public IActionResult getAttendanceReport(string id)
        {
            return Ok(studentAttendanceRepository.GetAllAttendancesByID(id));
        }
        [HttpGet("GetAttendReportof/{id}/{date}")]
        public IActionResult getAttendanceReport(string id,DateTime date)
        {
            return Ok(studentAttendanceRepository.GetAttendanceFromDate(id,date));
        }
    }
}
