﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SchoolManagementApi.Entity;
using SchoolManagementApi.Repository;

namespace SchoolManagementApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]



    public class UserController : ControllerBase
    {
        private readonly UserRepository userRepository;

        public UserController(UserRepository userRepository)
        {
            this.userRepository = userRepository;
        }
        [HttpPost("ADDUser")]
        public IActionResult AddUser(Users user)
        {
            userRepository.AddUser(user);
            return Ok(user);
        }
    }
}
