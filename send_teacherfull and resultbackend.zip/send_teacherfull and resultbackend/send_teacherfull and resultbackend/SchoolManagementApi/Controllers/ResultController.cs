﻿using AutoMapper;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SchoolManagementApi.DTOs;
using SchoolManagementApi.Entity;
using SchoolManagementApi.Model;
using SchoolManagementApi.Repositories;
using System.Runtime.InteropServices;

namespace SchoolManagementApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ResultController : ControllerBase
    {
        private readonly ResultRepository resultRepository;
        private readonly IMapper mapper;
        private readonly MyContext context;

        public ResultController(ResultRepository resultRepository, IMapper mapper, MyContext context)
        {
            this.resultRepository = resultRepository;
            this.mapper = mapper;
            this.context = context;
        }


        [HttpGet, Route("GetAllResult")]
        public IActionResult GetResults()
        {
            try
            {

                List<StdResult> t1 = resultRepository.AllResults();
                List<ResultDisplayDto> Getall = mapper.Map<List<ResultDisplayDto>>(t1);


                int i = 0;
                foreach (ResultDisplayDto result in Getall)
                {
                    result.ExamName=(from e in context.Examinations
                                     where e.ExamId == t1[i].ExmId
                                     select e.ExamName).Single();


                    int f = 0;
                    foreach (ResultDisplayDto resulta in Getall)
                    {
                        resulta.SubjectName = (from e in context.Subjects
                                               where e.SubId == t1[i].SubId
                                               select e.SubName).Single();
                    }
                    int a = 0;
                    foreach (ResultDisplayDto resultb in Getall)
                    {
                        resultb.StudName = (from e in context.Students
                                           where e.StudentId == t1[i].StuId
                                           select e.FirstName + " " + e.LastName).Single();
                    }
                    int c = 0;
                    foreach (ResultDisplayDto resultc in Getall)
                    {
                        resultc.ClassName = (from e in context.Classes
                                            where e.ClassId == t1[i].ClssId
                                            select e.Name).Single();
                    }
                    //int b = 0;
                    //foreach (ResultDisplayDto resultd in Getall)
                    //{
                    //    resultd.StudRoll = (from e in context.Students
                    //                       where e.StudentId == t1[i].StuId
                    //                       select e.Rollno).Single();
                    //}
                    //int d = 0;
                    //foreach (ResultDisplayDto resulte in Getall)
                    //{
                    //    resulte.Section = (from e in context.Classes
                    //                        where e.ClassId == t1[i].ClssId
                    //                        select e.Section).Single();
                    //}
              

                }








                return Ok(Getall);
            }
            catch (Exception)
            {

                throw;
            }
        }
        [HttpGet, Route("GetResultby/{id}")]
        public IActionResult GetById(string id)
        {
            try
            {
                StdResult t1 = resultRepository.GetById(id);
                ResultDisplayDto resultDTO = mapper.Map<ResultDisplayDto>(t1);


                    resultDTO.ExamName = (from e in context.Examinations
                                       where e.ExamId == t1.ExmId
                                       select e.ExamName).Single();


                resultDTO.StudName = (from e in context.Students
                                       where e.StudentId == t1.StuId
                                       select e.FirstName + " " + e.LastName).Single();


                //    resultDTO.StudRoll = (from e in context.Students
                //                       where e.StudentId == t1[i].StuId
                //                       select e.Rollno).Single();
                

                resultDTO.ClassName = (from e in context.Classes
                                        where e.ClassId == t1.ClssId
                                        select e.Name).Single();


                //    resultDTO.Section = (from e in context.Classes
                //                        where e.ClassId == t1[i].ClssId
                //                        select e.Section).Single();


                resultDTO.SubjectName = (from e in context.Subjects
                                           where e.SubId == t1.SubId
                                           select e.SubName).Single();



                

                return Ok(resultDTO);
            }
            catch (Exception)
            {

                throw;
            }
        }

    
    [HttpGet, Route("GetResultStudentby/{id}")]
    public IActionResult GetByStudentId(string id)
    {
        try
        {
            List<StdResult> t1 = resultRepository.GetByStudentId(id);
            List<ResultDisplayDto> resultDTO = mapper.Map<List<ResultDisplayDto>>(t1);


                int i = 0;
                foreach (var item in resultDTO)
                {
                    item.ExamName = (from e in context.Examinations
                                          where e.ExamId == t1[i].ExmId
                                          select e.ExamName).Single();


                    item.StudName = (from e in context.Students
                                          where e.StudentId == t1[i].StuId
                                          select e.FirstName + " " + e.LastName).Single();


                        item.StudRoll = (from e in context.Students
                                           where e.StudentId == t1[i].StuId
                                           select e.RollNO).Single();


                    item.ClassName = (from e in context.Classes
                                           where e.ClassId == t1[i].ClssId
                                           select e.Name).Single();


                       item.Section = (from e in context.Classes
                                            where e.ClassId == t1[i].ClssId
                                            select e.Section).Single();


                    item.SubjectName = (from e in context.Subjects
                                             where e.SubId == t1[i].SubId
                                             select e.SubName).Single();
                    item.Result = item.Mark >= 40 ? "Pass" : "Fail";



                }


                ResultReport resultReport = new ResultReport();

                resultReport.stdResults = resultDTO;

                float totalmark = 0;

                 
                    foreach (var item in resultDTO)
                    {
                    totalmark += item.Mark;
                    //if (item.Mark >= 40)
                    //{
                    //    item.Result = "Pass";
                    //}
                    //else
                    //{
                    //    item
                    //}
                    }
                resultReport.TotalMarks = totalmark.ToString();
                resultReport.Percentage = ((totalmark / (float)resultDTO.Count())).ToString();


                


                


            return Ok(resultReport);
        }
        catch (Exception)
        {

            throw;
        }
    }



    //Post actions
    [HttpPost, Route("AddResult")]
        public IActionResult AddResult([FromBody] ResultDto result)
        {
            try
            {
                StdResult resultdto = mapper.Map<StdResult>(result);
                if (ModelState.IsValid)
                {







                    resultRepository.AddResult(resultdto);

                    return Ok(resultdto);
                }

                return new JsonResult("Something went wrong") { StatusCode = 500 };
            }
            catch (Exception)
            {

                throw;
            }
        }



        //Put actions
        [HttpPut, Route("EditResult")]
        public IActionResult Update([FromBody] ResultDto result)
        {
            try
            {

                StdResult resultdto = mapper.Map<StdResult>(result);
                if (ModelState.IsValid)
                {
                    resultRepository.UpdateResult(resultdto);
                    return Ok(resultdto);
                }
                return new JsonResult("Something went wrong") { StatusCode = 500 };
            }
            catch (Exception)
            {

                throw;
            }
        }
        //Delete actions
        [HttpDelete, Route("DeleteResult/{id}")]
        public IActionResult Delete(string id)
        {
            resultRepository.DeleteResult(id);
            return Ok("resultt Deleted");
        }
    }
}
