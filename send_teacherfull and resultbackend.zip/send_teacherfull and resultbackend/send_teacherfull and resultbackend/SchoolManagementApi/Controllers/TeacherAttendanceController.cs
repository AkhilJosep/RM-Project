﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
//using NexusProjectIntegration.Entity;
using SchoolManagementApi.Entity;
using SchoolManagementApi.Repository;

namespace SchoolManagementApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TeacherAttendanceController : ControllerBase
    {
        private readonly TeacherAttendanceRepository teacherAttendanceRepository;

        public TeacherAttendanceController(TeacherAttendanceRepository teacherAttendanceRepository)
        {
            this.teacherAttendanceRepository = teacherAttendanceRepository;
        }

        [HttpPost("AddStudentAttendance")]
        public IActionResult AddStAttendace(TeacherAttendance teacherAttendance)
        {
            teacherAttendanceRepository.AddAttendance(teacherAttendance);
            return Ok(teacherAttendance);
        }
        [HttpGet("GetAttendReportof/{id}")]
        public IActionResult getAttendanceReport(string id)
        {
            return Ok(teacherAttendanceRepository.GetAllAttendancesByID(id));
        }
        [HttpGet("GetAttendReportof/{id}/{date}")]
        public IActionResult getAttendanceReport(string id, DateTime date)
        {
            return Ok(teacherAttendanceRepository.GetAttendanceFromDate(id, date));
        }
    }
}
