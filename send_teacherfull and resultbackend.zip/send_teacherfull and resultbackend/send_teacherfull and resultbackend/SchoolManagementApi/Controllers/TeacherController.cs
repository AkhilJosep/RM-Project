﻿using AutoMapper;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SchoolManagementApi.DTOs;
using SchoolManagementApi.Entity;
using SchoolManagementApi.Repositories;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace SchoolManagementApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TeacherController : ControllerBase
    {
        private readonly TeacherRepository teacherrepository;

        private readonly IMapper mapper;

        public TeacherController(TeacherRepository teacherrepository, IMapper mapper)
        {
            this.teacherrepository = teacherrepository;
            this.mapper = mapper;
        }

        [HttpGet, Route("GetAllTeachers")]
        public IActionResult GetTeachers()
        {
           List<Teachers> t1 = teacherrepository.GetTeachers().ToList();
            List<TeacherDToadd> Getall = mapper.Map<List<TeacherDToadd>>(t1);
            return Ok(Getall);
        }
        [HttpGet, Route("GetTeacher/{id}")]
        public IActionResult GetById(string id)
        {
            Teachers t1 = teacherrepository.GetBYid(id);
            TeacherDToadd teacherDTO = mapper.Map<TeacherDToadd>(t1);
            return Ok(teacherDTO);
        }
        //Post actions
        [HttpPost, Route("AddTeacher")]
        public IActionResult AddTeacher([FromBody] TeacherDToadd teacher)
        {
            Teachers teacherdto = mapper.Map<Teachers>(teacher);
            if (ModelState.IsValid)
            {
                teacherrepository.AddTeacher(teacherdto);

                return Ok(teacherdto);
            }

            return new JsonResult("Something went wrong") { StatusCode = 500 };
        }



        //Put actions
        [HttpPut, Route("EditTeacher")]
        public IActionResult Update([FromBody] TeacherDToadd teacher)
        {
            Teachers teacherdto = mapper.Map<Teachers>(teacher);
            if (ModelState.IsValid)
            {
                teacherrepository.EditTeacher(teacherdto);
                return Ok(teacherdto);
            }
            return new JsonResult("Something went wrong") { StatusCode= 500 };
        }
        //Delete actions
        [HttpDelete, Route("DeleteTeacher/{id}")]
        public IActionResult Delete(string id)
        {
            teacherrepository.DeleteTeacher(id);
            return Ok("Student Deleted");
        }

        [HttpGet, Route("GetTeacherbsubject/{subject}")]
        public IActionResult GetBysubject(string subject)
        {

            List<Teachers> t1 = teacherrepository.GetBysubject(subject).ToList();
            List<TeacherDToadd> GetBYsubject = mapper.Map<List<TeacherDToadd>>(t1);
            return Ok(GetBYsubject);
        }
    }
}
