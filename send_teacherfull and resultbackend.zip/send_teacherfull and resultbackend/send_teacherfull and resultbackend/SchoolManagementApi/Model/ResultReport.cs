﻿using SchoolManagementApi.DTOs;
using SchoolManagementApi.Entity;

namespace SchoolManagementApi.Model
{
    public class ResultReport
    {
        public List<ResultDisplayDto> stdResults {  get; set; }
        public string Percentage {  get; set; }
        public string TotalMarks {  get; set; }


    }
}
