﻿

using SchoolManagementApi.Entity;

namespace SchoolManagementApi.Repositories
{
    public class ResultRepository : IResult
    {
        private readonly MyContext _context;

        public ResultRepository(MyContext context)
        {
            _context = context;
        }

        public void AddResult(StdResult result)
        {
            try
            {
                _context.stdResults.Add(result);
                _context.SaveChanges();
            }
            catch (Exception)
            {

                throw;
            }
           
        }

        public List<StdResult> AllResults()
        {
            try
            {
                return _context.stdResults.ToList();
            }
            catch (Exception)
            {

                throw;
            }
        }

        public void DeleteResult(string id)
        {
            StdResult result = _context.stdResults.Find(id);
            _context .stdResults.Remove(result);
            _context.SaveChanges();
        }

        public StdResult GetById(string id)
        {
            try
            {
                return _context.stdResults.Find(id);
            }
            catch (Exception)
            {

                throw;
            }
        }
        public List<StdResult> GetByStudentId(string id)
        {
            try
            {
                return (_context.stdResults.Where(r=>r.StuId==id)).ToList();
            }
            catch (Exception)
            {

                throw;
            }
        }

        public void UpdateResult(StdResult result)
        {
            try
            {
                _context.stdResults.Update(result);
                _context.SaveChanges();
            }
            catch (Exception)
            {

                throw;
            }
        }
    }
}
