﻿using Microsoft.EntityFrameworkCore;
using SchoolManagementApi.DTOs;
using SchoolManagementApi.Entity;

namespace SchoolManagementApi.Repositories
{
    public class TeacherRepository : ITeacher
    {
        private readonly MyContext context;
        public TeacherRepository(MyContext context)
        { 
            this.context = context;
        }
        public void AddTeacher(Teachers teacher)
        {
            try
            {
                context.Teachers.Add(teacher);
                context.SaveChanges();
            }
            catch (Exception)
            {

                throw;
            }
        }

        public void DeleteTeacher(string id)
        {
            try
            {
                Teachers teacher = context.Teachers.Find(id);
               context.Teachers.Remove(teacher);
                context.SaveChanges();
            }
            catch (Exception)
            {

                throw;
            }
        }

        public void EditTeacher(Teachers teacher)
        {
            try
            {
            
                context.Teachers.Update(teacher);
                context.SaveChanges();
            }
            catch (Exception)
            {

                throw;
            }
        }



        public Teachers GetBYid(string id)
        {
            return context.Teachers.Find(id);
        }

        public List<Teachers> GetBysubject(string subject)
        {
            try
            {
                List<Teachers> teachersbycls = context.Teachers.Where((e)=> e.Subject.SubName == subject).ToList();
              return teachersbycls;
               

            }
            catch (Exception)
            {

                throw;
            }
        }
        
        public List<Teachers> GetTeachers()
        {
            try
            {
                return context.Teachers.ToList();
            }
            catch (Exception)
            {

                throw;
            }
        }
    }
}
