﻿using SchoolManagementApi.Entity;
namespace SchoolManagementApi.Repositories
{
    public interface IResult
    {
        List<StdResult> AllResults();

        void AddResult(StdResult result);
        void UpdateResult (StdResult result);

        void DeleteResult(string id);
        StdResult GetById(string id);
        

    }
}
