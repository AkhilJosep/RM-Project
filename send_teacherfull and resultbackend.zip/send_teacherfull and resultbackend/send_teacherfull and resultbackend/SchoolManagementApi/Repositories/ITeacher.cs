﻿using SchoolManagementApi.DTOs;
using SchoolManagementApi.Entity;

namespace SchoolManagementApi.Repositories
{
    public interface ITeacher
    {
        List<Teachers> GetTeachers();
        void AddTeacher(Teachers  teacher);
        void DeleteTeacher(string id);

        void EditTeacher(Teachers teacher);

        Teachers GetBYid(string id);

        List<Teachers> GetBysubject(string subject);
    }
}
