﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace SchoolManagementApi.Entity
{
    public class Teachers
    {
        [Key]
        public string TeacherId { get; set; }
        [Required]
        public string FirstName { get; set; } = " ";
        [Required]
        public string LastName { get; set; } = " ";
        [Required]
        public DateTime DOB { get; set; } = new DateTime();
        [Required]
        public string Gender { get; set; } = " ";
        [Required]
        [EmailAddress(ErrorMessage = "Invalid Email Address")]
        public string Email { get; set; } = "abc@gmail.com";
        [Required]
        [Column("Mobile No")]
        public string MobileNum { get; set; }
        public string SubjId { get; set; } = " ";
	
        [ForeignKey("SubjId")]
        public Subject? Subject { get; set; }
    }
}
