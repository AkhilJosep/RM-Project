﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using SchoolManagementApi.Entity;

namespace SchoolManagementApi.Entity
{
    [Table("Class")]
    public class ScheduleClass
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public string ScheduleId { get; set; }
        [Required]
        public string ClassId { get; set; }
        [Required]
        public string SessionTime { get; set; }
        [Required]
        public string TeacId { get; set; }
        [Required]
        public string SubjId { get; set; }

        [ForeignKey("TeacId")]
       public Teachers? Teacher { get; set; }
        [ForeignKey("SubjId")]
       public Subject? Subject { get; set; }
        [ForeignKey("ClassId")]
       public Classes? classe { get; set; }

    }
}
