﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SchoolManagementApi.Entity
{
    public class Examinations
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public string ExamId { get; set; }
        [Required]
        public string ExamName { get; set; }
        [Required]
        public DateTime ExamDate { get; set; }
        [Required]
        [Column("ClsId")]
        public string ClassId { get; set;}
        [Column("SubId")]
        public string SubjectId { get; set; }

        [ForeignKey("ClassId")]
        public Classes? Cls { get; set; }

        [ForeignKey("SubjectId")]
        public Subject subject { get; set; }


    }
}
