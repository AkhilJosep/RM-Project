﻿using System.ComponentModel.DataAnnotations;

namespace SchoolManagementApi.Entity
{
    public class TeacherRegister
    {
        [Key]
        public string TchrRegId {  get; set; }
    }
}
