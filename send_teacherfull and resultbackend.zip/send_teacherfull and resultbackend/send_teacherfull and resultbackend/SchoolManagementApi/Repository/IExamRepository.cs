﻿using SchoolManagementApi.Entity;

namespace SchoolManagementApi.Repository
{
    public interface IExamRepository
    {
        void AddExam(Examinations exam);
    }
}
