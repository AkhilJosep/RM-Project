﻿using SchoolManagementApi.Entity;

namespace SchoolManagementApi.Repository
{
    public class UserRepository
    {
        private readonly MyContext myContext;

        public UserRepository(MyContext myContext)
        {
            this.myContext = myContext;
        }

        public void AddUser(Users user)
        {
            myContext.Users.Add(user);
            myContext.SaveChanges();
        }
    }
}
