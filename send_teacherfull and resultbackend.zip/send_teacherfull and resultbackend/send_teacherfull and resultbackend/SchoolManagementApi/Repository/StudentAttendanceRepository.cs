﻿using SchoolManagementApi.Entity;

namespace SchoolManagementApi.Repository
{
    public class StudentAttendanceRepository : IAttendanceRepository<StudentAttendance>
    {
        private readonly MyContext mycontext;

        public StudentAttendanceRepository(MyContext context)
        {
            mycontext = context;
        }

        public void AddAttendance(StudentAttendance attendace)
        {
            mycontext.StudentAttendance.Add(attendace);
            mycontext.SaveChanges();
        }

        public List<StudentAttendance> GetAllAttendancesByID(string id)
        {
            List<StudentAttendance> studentAttendances=mycontext.StudentAttendance.ToList();

            var attList=(from s in studentAttendances
            where s.StudentId == id
            select s).ToList();

            return attList;
            
        }


        public List<StudentAttendance> GetAttendanceFromDate(string id, DateTime date)
        {
            List<StudentAttendance> studentAttendances = mycontext.StudentAttendance.ToList();

            var attList = (from s in studentAttendances
                           where s.StudentId == id && s.Date.Date>=date.Date
                           select s).ToList();

            return attList;
        }
    }
}
