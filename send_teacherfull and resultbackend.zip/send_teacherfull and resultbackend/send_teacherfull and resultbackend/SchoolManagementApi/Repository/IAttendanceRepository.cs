﻿namespace SchoolManagementApi.Repository
{
    public interface IAttendanceRepository<T> where T : class
    {
        void AddAttendance(T attendace);
        List<T> GetAllAttendancesByID(string id);
        List<T> GetAttendanceFromDate(string id,DateTime date);

    }
}
