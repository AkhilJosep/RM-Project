﻿using Microsoft.EntityFrameworkCore;
using SchoolManagementApi.Entity;

namespace SchoolManagementApi.Repository
{
    public class TeacherAttendanceRepository : IAttendanceRepository<TeacherAttendance>
    {
        private readonly MyContext myContext;

        public TeacherAttendanceRepository(MyContext myContext)
        {
            this.myContext = myContext;
        }

        public void AddAttendance(TeacherAttendance attendace)
        {
            myContext.TeacherAttendance.Add(attendace);
            myContext.SaveChanges();
        }

        public List<TeacherAttendance> GetAllAttendancesByID(string id)
        {
            List<TeacherAttendance> teacherAttendances = myContext.TeacherAttendance.ToList();

            var attList = (from s in teacherAttendances
                           where s.TeacherId == id
                           select s).ToList();

            return attList;
        }

        public List<TeacherAttendance> GetAttendanceFromDate(string id, DateTime date)
        {
            List<TeacherAttendance> teacherAttendances = myContext.TeacherAttendance.ToList();

            var attList = (from s in teacherAttendances
                           where s.TeacherId == id && s.Date.Date >= date.Date
                           select s).ToList();

            return attList;
        }
    }
}
