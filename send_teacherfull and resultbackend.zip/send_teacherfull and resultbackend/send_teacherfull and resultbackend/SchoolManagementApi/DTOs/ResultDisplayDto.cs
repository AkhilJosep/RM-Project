﻿namespace SchoolManagementApi.DTOs
{
    public class ResultDisplayDto
    {
        public string MarksId { get; set; }
        public string ExamName {  get; set; }

        public string StudName {  get; set; }

        public string StuId { get; set; }
        public string StudRoll{ get; set;}

        public string ClassName {  get; set; }

        public string Section {  get; set; }
        public int Mark { get; set; }
        public string Result { get; set; }
        public string SubjectName {  get; set; }
    }
}
