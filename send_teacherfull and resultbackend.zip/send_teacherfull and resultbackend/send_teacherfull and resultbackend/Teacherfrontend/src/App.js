import logo from './logo.svg';
import './App.css';
import ClassScheduleForm from './classschedule'
import GetByid from './da';
import CRUD from './AddTeacher';
import Id from './GetTByid';
import GetSub from './GetTbysub';

import GetBystudId from './AttendanceBYSTUDId';
import GetByteachId from './AttendanceByTeachId';

function App() {
  return (
    <div className="App">
      {/* <ClassScheduleForm/> */}
{/*     
      <GetByid/>
      <GetByClass/>
      <GetBysub/> */} 
      {/* <GetTeachers/> */}
       {/* <CRUD/>  */}
       {/* <Id/> */}
      {/* <GetSub/>  */}
      {/* <ClassScheduleForm/>
      */}
      {/* <Attendance/> */}
{/* <GetByteachId/> */}
     {/* <GetBystudId/> */}


    </div>
  );
}

export default App;
