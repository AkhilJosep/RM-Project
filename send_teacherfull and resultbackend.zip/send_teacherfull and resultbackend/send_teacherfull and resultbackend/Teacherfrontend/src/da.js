import React, { useState } from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import "../src/Styles.css/GetBYid.css";

function GetByid() {
  const teachers = [
    {
        id: 1,
        teacherId: 'teacher1',
        firstName: 'John',
        lastName: 'Doe',
        gender: 'Male',
        dob: '01-01-1980',
        gmail: 'john.doe@example.com',
        subjectsTaught: ['Math', 'Science'],
        classesHandled: ['Class 1', 'Class 2']
      },
      {
        id: 2,
        teacherId: 'teacher2',
        firstName: 'Jane',
        lastName: 'Smith',
        gender: 'Female',
        dob: '02-02-1985',
        gmail: 'jane.smith@example.com',
        subjectsTaught: ['English', 'History'],
        classesHandled: ['Class 3', 'Class 4']
      },
      {
        id: 3,
        teacherId: 'teacher3',
        firstName: 'Bob',
        lastName: 'Johnson',
        gender: 'Male',
        dob: '03-03-1990',
        gmail: 'bob.johnson@example.com',
        subjectsTaught: ['Physics', 'Chemistry'],
        classesHandled: ['Class 5', 'Class 6']
      },
      {
          id: 4,
          teacherId: 'teacher4',
          firstName: 'faris',
          lastName: 'Johnson',
          gender: 'Male',
          dob: '03-03-1997',
          gmail: 'bob.johnson@example.com',
          subjectsTaught: ['Physics', 'Chemistry'],
          classesHandled: ['Class 5', 'Class 6']
        },
        {
          id: 5,
          teacherId: 'teacher5',
          firstName: 'Sagar',
          lastName: 'Johnson',
          gender: 'Male',
          dob: '03-03-1995',
          gmail: 'bob.json@example.com',
          subjectsTaught: ['Physics', 'Chemistry'],
          classesHandled: ['Class 8', 'Class 6']
        }
  ];
  const [teacherId, setTeacherId] = useState("");
  const [teacher, setTeacher] = useState(null);

  const handleSubmit = (event) => {
    event.preventDefault();
    const foundTeacher = teachers.find((t) => t.teacherId === teacherId);
    if (foundTeacher) {
      setTeacher(foundTeacher);
    } else {
      alert("Teacher not found");
    }
  };

  return (
    <div className="container text-center">
      <h3 className="my-4">Enter Teacher ID:</h3>
      <form onSubmit={handleSubmit} className="form-inline">
        <div className="form-group mx-sm-3">
          <input
            type="text"
            className="form-control"
            value={teacherId}
            onChange={(event) => setTeacherId(event.target.value)}
          />
        </div>
        <button type="submit" className="btn btn-primary">
          Submit
        </button>
      </form>
      {teacher && (
        <div className="my-4">
          <h3>Teacher Details:</h3>
          <table className="table">
            <thead>
              <tr>
                <th scope="col">Teacher ID</th>
                <th scope="col">First Name</th>
                <th scope="col">Last Name</th>
                <th scope="col">Gender</th>
                <th scope="col">D.O.B</th>
                <th scope="col">Gmail</th>
                <th scope="col">Subjects Taught</th>
                <th scope="col">Classes Handled</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>{teacher.teacherId}</td>
                <td>{teacher.firstName}</td>
                <td>{teacher.lastName}</td>
                <td>{teacher.gender}</td>
                <td>{teacher.dob}</td>
                <td>{teacher.gmail}</td>
                <td>{teacher.subjectsTaught.join(", ")}</td>
                <td>{teacher.classesHandled.join(", ")}</td>
              </tr>
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

export default GetByid;