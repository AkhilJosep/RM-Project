import React, { useState } from "react";
import axios from "axios";

const Id = () => {
  const [teacherId, setId] = useState("");
  const [teacherDetails, setTeacherDetails] = useState(null); // State variable to store teacher details

  const getById = () => {
    axios
      .get("http://localhost:5247/api/Teacher/GetTeacher/" + teacherId)
      .then((response) => {
        setTeacherDetails(response.data); // Update state with fetched teacher details
      })
      .catch((error) => console.log(error));
  };




  return (
    <div className="container">
      <div>
        <input
          type="text"
          value={teacherId}
          onChange={(e) => setId(e.target.value)}
        />
        <button onClick={getById}>Get Teacher By ID</button>
     
      </div>
      {teacherDetails && (
        <table className="table">
          <tbody>
            <tr>
              <td>ID</td>
              <td>{teacherDetails.teacherId}</td>
            </tr>
            <tr>
              <td>First Name</td>
              <td>{teacherDetails.firstName}</td>
            </tr>
            <tr>
              <td>Last Name</td>
              <td>{teacherDetails.lastName}</td>
            </tr>
            <tr>
              <td>Email</td>
              <td>{teacherDetails.email}</td>
            </tr>
            <tr>
              <td>Date of Birth</td>
              <td>{teacherDetails.dob}</td>
            </tr>
            <tr>
              <td>Gender</td>
              <td>{teacherDetails.gender}</td>
            </tr>
            <tr>
              <td>Subject Taught</td>
              <td>{teacherDetails.subjectTaught}</td>
            </tr>
            <tr>
              <td>Class ID</td>
              <td>{teacherDetails.classid}</td>
            </tr>
          </tbody>
        </table>
      )}
    </div>
  );
};

export default Id;