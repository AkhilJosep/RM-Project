import Table from 'react-bootstrap/Table';
import React,{useState,useEffect, Fragment} from "react"
import Button from 'react-bootstrap/Button';
import Modal from 'react-bootstrap/Modal';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import Container from 'react-bootstrap/Container';
import axios from 'axios';
import {ToastContainer,toast} from "react-toastify"
import "react-toastify/dist/ReactToastify.css"
<script src="../../Jquery/prettify.js"></script>
const CRUD =()=>{

    const [show, setShow] = useState(false);
    const handleClose = () => setShow(false);
    const handleShow = () => setShow(true);
    const [id,setId] = useState("")
    const [firstname,setfirstname] = useState("")
    const [lastName,setlastname] = useState("")
    const [email,setemail] = useState("")
    const [dob,setdob] = useState("")
    const [gender,setgender] = useState("")
    const [subjectsTaught,setsubjecttaught] = useState("")
    const [classId,setClass] = useState("")

    const [data,setdata] = useState([])
    const handleSave =() =>{
        const url ='http://localhost:5247/api/Teacher/AddTeacher'
        const data = {
          "teacherId": id,
          "firstName": firstname,
          "lastName": lastName,
          "email": email,
          "dob": dob,
          "gender": gender,
          "subjectTaught": subjectsTaught,
          "clsid": classId
        }
        axios.post(url,data)
        .then((result)=>{
          console.log(result.data);
          console.log("entering add post");
          getData();
          clear();
          toast.success("Teacher has been added")
        })
        .catch((error)=>{
          toast.error(error)
        })
      }
      
      const clear = ()=>{
        setId('')
        setfirstname('')
        setlastname("")
        setemail('')
        setdob('')
        setgender("")
        setsubjecttaught('')
        setClass('')
        seteditId('')
        setEditFname('')
        setEditLname('')
        setEditEmail('')
        setEditGender('')
        setEditDob('')
        seteditsubjecttaught('')
      }
    
    }
    
    return(
        <Fragment>
          <ToastContainer/>
          <Container>
            <Row>
            <Col>

          <input type="text" className='form-control form-control-sm' placeholder='Enter TeacherId '
           value={id} onChange={(e)=> setId(e.target.value)} />
        </Col>
            </Row>
      <Row className='pt-2'>
      <Col>
        <input type="text" className='form-control form-control-sm' placeholder='Enter firstname '
        value={firstname} onChange={(e)=> setfirstname(e.target.value)} />
        </Col>
        
      <Col>
        <input type="text" className='form-control form-control-sm' placeholder='Enter lastName'
        value={lastName} onChange={(e)=> setlastname(e.target.value)} />
        </Col>
        <Col>
        <input type="text" className='form-control form-control-sm' placeholder='Enter email'
        value={email} onChange={(e)=> setemail(e.target.value)} />
        </Col>
        </Row>
        <Row className='pt-2'>
        
        <Col>
        <input type="text" className='form-control form-control-sm' placeholder='Enter dob'
        value={dob} onChange={(e)=> setdob(e.target.value)} />
        </Col>
        <Col>
        <input type="text" className='form-control form-control-sm' placeholder='Enter gender'
        value={gender} onChange={(e)=> setgender(e.target.value)} />
        </Col>
        <Col>
        <input type="text" className='form-control form-control-sm' placeholder='Enter Subjecttaught'
        value={subjectsTaught} onChange={(e)=> setsubjecttaught(e.target.value)} />
        </Col>
        <Col>
        <input type="text" className='form-control form-control-sm' placeholder='Enter Class'
        value={classId} onChange={(e)=> setClass(e.target.value)} />
        </Col>
        
        
        </Row>
        <Row className='pt-2'>
        <Col>
        <button className='btn btn-primary '   onClick={()=>handleSave()}>Add Student</button>
      
        </Col>
      </Row>
     
    </Container>  
    </Fragment>
    );
    