import React from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import "../src/Styles.css/ClassScheduleForm.css";


class ClassScheduleForm extends React.Component {
  constructor(props) {
    super(props);
    this.handleSubmit = this.handleSubmit.bind(this);
  }

  handleSubmit(event) {
    alert(
      `Class ID: ${event.target.classid.value}, Class Name: ${event.target.classname.value}, Section: ${event.target.section.value}, Teacher: ${event.target.teacher.value}`
    );
    event.preventDefault();
  }

  render() {
    return (
        <div className="class-schedule-form-container">
        <h3 className="title">Class Schedule Form</h3>
        <form onSubmit={this.handleSubmit} className="class-schedule-form">
        <div className="form-group">
          <label htmlFor="classid">Class ID</label>
          <input
            type="text"
            className="form-control"
            id="classid"
            name="classid"
          />
        </div>
        <div className="form-group">
          <label htmlFor="classname">Class Name</label>
          <input
            type="text"
            className="form-control"
            id="classname"
            name="classname"
          />
        </div>
        <div className="form-group">
          <label htmlFor="section">Section</label>
          <input
            type="text"
            className="form-control"
            id="section"
            name="section"
          />
        </div>
        <div className="form-group">
          <label htmlFor="teacher">Teacher</label>
          <select className="form-control" id="teacher" name="teacher">
            <option value="teacher1">Teacher 1</option>
            <option value="teacher2">Teacher 2</option>
            <option value="teacher3">Teacher 3</option>
            {/* Add more options as needed */}
          </select>
        </div >
        <div id="classsubmit">
        <button type="submit" className="btn btn-dark">
          schedule class
        </button>
        </div>
      </form>
      </div>
    );
  }
}

      
    

export default ClassScheduleForm;