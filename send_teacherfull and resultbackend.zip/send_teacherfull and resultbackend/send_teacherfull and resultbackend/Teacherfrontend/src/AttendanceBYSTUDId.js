import React, { useState } from "react";
import axios from "axios";

const GetBystudId = () => {
  const [AttendanceBYStudId, setAttendanceBYStudId] = useState("");
  const [AttendanceList, SetAttendanceList] = useState([]); // State variable to store teacher details

  const getBystudId = () => {
    axios
      .get(`http://localhost:5247/api/Teacher/GetTeacherbsubject/${AttendanceBYStudId}`)
      .then((response) => {
        SetAttendanceList(response.data); // State variable to store teacher details
       console.log(response.data); // Update state with fetched teacher details
      })
      .catch((error) => console.log(error));
  };

  return (
    <div className="container">
      <div>
        <input
          type="text"
          value={AttendanceBYStudId}
          onChange={(e) => setAttendanceBYStudId(e.target.value)}
        />
        <button onClick={getBystudId}>Get Attendance By StudentId</button>
      </div>
      {AttendanceList.length > 0 && (
        <table className="table">
          <thead>
            <tr>
              <th>No.Of Days Pressent</th>
              <th>Total No.Of Working days</th>
              <th>Attendance Percentage</th>
            
            </tr>
          </thead>
          <tbody>
            {AttendanceList.map((Attendance, index) => (
              <tr key={index}>
                <td>{Attendance.No.OfDaysPressent}</td>
                <td>{Attendance.TotalNo.OfWorkingdays}</td>
                <td>{Attendance.AttendancePercentage}</td>
                
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
};

export default GetBystudId;