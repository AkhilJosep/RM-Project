import React, { useState } from "react";
import axios from "axios";

const GetSub = () => {
  const [subjectTaught, setSubjectTaught] = useState("");
  const [teacherList, setTeacherList] = useState([]); // State variable to store teacher details

  const getBysub = () => {
    axios
      .get(`http://localhost:5247/api/Teacher/GetTeacherbsubject/${subjectTaught}`)
      .then((response) => {
        setTeacherList(response.data); // Update state with fetched teacher details
      })
      .catch((error) => console.log(error));
  };

  return (
    <div className="container">
      <div>
        <input
          type="text"
          value={subjectTaught}
          onChange={(e) => setSubjectTaught(e.target.value)}
        />
        <button onClick={getBysub}>Get Teachers By Subject</button>
      </div>
      {teacherList.length > 0 && (
        <table className="table">
          <thead>
            <tr>
              <th>ID</th>
              <th>First Name</th>
              <th>Last Name</th>
              <th>Email</th>
              <th>Date of Birth</th>
              <th>Gender</th>
              <th>Subject Taught</th>
              <th>Class ID</th>
            </tr>
          </thead>
          <tbody>
            {teacherList.map((teacher, index) => (
              <tr key={index}>
                <td>{teacher.teacherId}</td>
                <td>{teacher.firstName}</td>
                <td>{teacher.lastName}</td>
                <td>{teacher.email}</td>
                <td>{teacher.dob}</td>
                <td>{teacher.gender}</td>
                <td>{teacher.subjectTaught}</td>
                <td>{teacher.classid}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
};

export default GetSub;