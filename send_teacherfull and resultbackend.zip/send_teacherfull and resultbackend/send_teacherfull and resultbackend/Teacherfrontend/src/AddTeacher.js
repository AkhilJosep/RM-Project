import Table from 'react-bootstrap/Table';
import React,{useState,useEffect, Fragment} from "react"
import Button from 'react-bootstrap/Button';
import Modal from 'react-bootstrap/Modal';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import Container from 'react-bootstrap/Container';
import axios from 'axios';
import {ToastContainer,toast} from "react-toastify"
import "react-toastify/dist/ReactToastify.css"
<script src="../../Jquery/prettify.js"></script>
const CRUD =()=>{

    const [show, setShow] = useState(false);
    const handleClose = () => setShow(false);
    const handleShow = () => setShow(true);
    // const data = {
    //   "teacherId": id,
    //   "firstName": firstname,
    //   "lastName": lastName,
    //   "email": rollno,
    //   "dob": dob,
    //   "gender": gender,
    //   "subjectTaught": email,
    //   "clsid": classId
    // }setfirstname

    const [id,setId] = useState("")
    const [firstname,setfirstname] = useState("")
    const [lastName,setlastname] = useState("")
    const [email,setemail] = useState("")
    const [dob,setdob] = useState("")
    const [gender,setgender] = useState("")
    const [subjectsTaught,setsubjecttaught] = useState("")
    const [classId,setClass] = useState("")

    const [editId,seteditId] = useState("")
    const [editfirstname,setEditFname] = useState("")
    const [editlastName,setEditLname] = useState("")
    const [editemail,setEditEmail] = useState("")
    const [editdob,setEditDob] = useState("")
    const [editgender,setEditGender] = useState("")
    const [editclassId,setEditClass] = useState("")
    const[editSubjectTaught,seteditsubjecttaught]= useState("")


   

    const [data,setdata] = useState([])

    useEffect(()=>{
        // setdata(stdData)
        getData()
    },[])

    const getData =()=>{
      axios.get('http://localhost:5247/api/Teacher/GetAllTeachers')
      .then((result)=>{
        setdata(result.data)
        console.log(result.data);
      })
      .catch((error)=>{
        console.log(error);
      })
    }
    // function GetByid() {
    //   const teachers = []
    //     { const [teacherId, setTeacherId] = useState("");
    //     const [teacher, setTeacher] = useState(null);
      
    //     const handleSubmit = (event) => {
    //       event.preventDefault();
    //       const foundTeacher = teachers.find((t) => t.teacherId === teacherId);
    //       if (foundTeacher) {
    //         setTeacher(foundTeacher);
    //       } else {
    //         alert("Teacher not found");
    //       }
    //     };
      


    const handleEdit =(teacherId)=>{
       handleShow();
       axios.get(`http://localhost:5247/api/Teacher/GetTeacher/${teacherId}`)
       .then((result)=>{
        
        console.log(result);
        setEditFname(result.data.firstName)
        setEditLname(result.data.lastName)
        setEditEmail(result.data.email)
        setEditGender(result.data.gender)
        setEditDob(result.data.dob)
        seteditId(result.data.teacherId)
        seteditsubjecttaught(result.data.subjectTaught)
        setEditClass(result.data.clsid)
       })
       .catch((error)=>{
        toast.error(error)
       })
    }

    const handleDelete =(teacherId)=>
    {
      if(window.confirm("Are you sure to delete this employe") === true){
        axios.delete(`http://localhost:5247/api/Teacher/DeleteTeacher/${teacherId}`)
        .then((result)=>{
          if(result.status === 200)
          {
            toast.success("Deleted succesfully")
            getData();
          }
          
        })
        .catch((error)=>{
          toast.error(error)
        })
      }
     
    }


    const handleUpdate = ()=>{
     console.log("check");
     const url ='http://localhost:5247/api/Teacher/EditTeacher'
     const data = {
      "teacherId": editId,
      "firstName": editfirstname,
      "lastName": editlastName,
      "email": editemail,
      "dob": editdob,
      "gender": editgender,
      "subjectTaught": editSubjectTaught,
      "clsid": editclassId
    }
    console.log(data);
    
    axios.put(url,data)
    .then((result)=>{
      console.log("Entered into edit api");
      handleClose()
      console.log(result.data);
      getData();
      // clear();
      toast.success("Teacher has been updated")
    })
    .catch((error)=>{
      toast.error(error)
    })
    }

    const handleSave =() =>{
      const url ='http://localhost:5247/api/Teacher/AddTeacher'
      const data = {
        "teacherId": id,
        "firstName": firstname,
        "lastName": lastName,
        "email": email,
        "dob": dob,
        "gender": gender,
        "subjectTaught": subjectsTaught,
        "clsid": classId
      }
      axios.post(url,data)
      .then((result)=>{
        console.log(result.data);
        console.log("entering add post");
        getData();
        clear();
        toast.success("Teacher has been added")
      })
      .catch((error)=>{
        toast.error(error)
      })
    }
    
    const clear = ()=>{
      setId('')
      setfirstname('')
      setlastname("")
      setemail('')
      setdob('')
      setgender("")
      setsubjecttaught('')
      setClass('')
      seteditId('')
      setEditFname('')
      setEditLname('')
      setEditEmail('')
      setEditGender('')
      setEditDob('')
      seteditsubjecttaught('')
    }
  

    return(
        <Fragment>
          <ToastContainer/>
          <Container>
            <Row>
            <Col>

          <input type="text" className='form-control form-control-sm' placeholder='Enter TeacherId '
           value={id} onChange={(e)=> setId(e.target.value)} />
        </Col>
            </Row>
      <Row className='pt-2'>
      <Col>
        <input type="text" className='form-control form-control-sm' placeholder='Enter firstname '
        value={firstname} onChange={(e)=> setfirstname(e.target.value)} />
        </Col>
        
      <Col>
        <input type="text" className='form-control form-control-sm' placeholder='Enter lastName'
        value={lastName} onChange={(e)=> setlastname(e.target.value)} />
        </Col>
        <Col>
        <input type="text" className='form-control form-control-sm' placeholder='Enter email'
        value={email} onChange={(e)=> setemail(e.target.value)} />
        </Col>
        </Row>
        <Row className='pt-2'>
        
        <Col>
        <input type="text" className='form-control form-control-sm' placeholder='Enter dob'
        value={dob} onChange={(e)=> setdob(e.target.value)} />
        </Col>
        <Col>
        <input type="text" className='form-control form-control-sm' placeholder='Enter gender'
        value={gender} onChange={(e)=> setgender(e.target.value)} />
        </Col>
        <Col>
        <input type="text" className='form-control form-control-sm' placeholder='Enter Subjecttaught'
        value={subjectsTaught} onChange={(e)=> setsubjecttaught(e.target.value)} />
        </Col>
        <Col>
        <input type="text" className='form-control form-control-sm' placeholder='Enter Class'
        value={classId} onChange={(e)=> setClass(e.target.value)} />
        </Col>
        
        
        </Row>
        <Row className='pt-2'>
        <Col>
        <button className='btn btn-primary '   onClick={()=>handleSave()}>Add Student</button>
      
        </Col>
      </Row>
     
    </Container>
    <br></br>
    <div className='pt-2'>
      <Table striped bordered hover>
      <thead>
        <tr>
          <th>index</th>
          <th>TeacherId</th>
          <th>FirstName</th>
          <th>LastName</th>
          <th>Email</th>
          <th>DOB</th>
          <th>Gender</th>
          <th>SubjectTaught</th>
          <th>classid</th>
        </tr>
      </thead>
      <tbody>
        {
          data && data.length > 0 ?
          data.map((item,index)=>{
            return (
              <tr key={index}>
              <td>{index+1}</td>
              <td>{item.teacherId}</td>
              <td>{item.firstName}</td>
              <td>{item.lastName}</td>
              <td>{item.email}</td>
              <td>{item.dob}</td>
              <td>{item.gender}</td>
              <td>{item.subjectTaught}</td>
              <td>{item.clsid}</td>
              
              <td colSpan={2}>
             
              {/* <button className='btn btn-primary'  onClick={(id)=>GetById(item.teacherId)} >GetBYid</button> &nbsp; */}
                <button className='btn btn-primary'  onClick={()=>handleEdit(item.teacherId)} >Edit</button> &nbsp;
                <button className='btn btn-danger' onClick={()=> handleDelete(item.teacherId)}  >Delete</button>
              </td>
            </tr>
            )
          })
          :
          'Loading.......'
        }
       
      </tbody>
    </Table>
    </div>
    <Modal show={show} onHide={handleClose}>
        <Modal.Header closeButton>
          <Modal.Title>Modify /Update employe</Modal.Title>
        </Modal.Header>
        <Modal.Body>
        <Row className='pt-2'>
        <Col>
        <input type="text" className='form-control' placeholder='Enter firstname'
        value={editfirstname} onChange={(e)=> setEditFname(e.target.value)} />
        </Col>
        <Col>
        <input type="text" className='form-control' placeholder='Enter Lastname'
        value={editlastName} onChange={(e)=> setEditLname(e.target.value)} />
        </Col>
        <Col>
        <input type="text" className='form-control' placeholder='Enter Email'
        value={editemail} onChange={(e)=> setEditEmail(e.target.value)} />
        </Col>
      </Row>
      <Row className='pt-2'>
        <Col>
        <input type="text" className='form-control' placeholder='Enter Gender'
        value={editgender} onChange={(e)=> setEditGender(e.target.value)} />
        </Col>
        <Col>
        <input type="text" className='form-control' placeholder='Enter Dob '
        value={editdob} onChange={(e)=> setEditDob(e.target.value)} />
        </Col>
        <Col>
        <input type="text" className='form-control' placeholder='Enter className'
        value={editclassId} onChange={(e)=> setEditClass(e.target.value)} />
        </Col>
      </Row>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={handleClose}>
            Close
          </Button>
          <Button variant="primary" onClick={handleUpdate}>
            Save Changes
          </Button>
        </Modal.Footer>
      </Modal>
        </Fragment>
    )
}

export default CRUD;